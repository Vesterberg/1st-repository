bool IsBoiling(int temperature);
int CelciusToFahrenheit(int celcius);
float CelciusToFahrenheit(float celcius);
